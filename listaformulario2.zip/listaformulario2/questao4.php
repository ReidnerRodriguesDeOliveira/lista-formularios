<?php
header("Content-type:text/html;charset=utf8");
     $uni = $_POST["uni"];
     $temp = $_POST["temp"];          
if($uni == "celsius" ){echo "em fahrenheit" .($temp*1.8+32);
}elseif($uni == "fahrenheit"){echo"em celsius".($temp-32)*1.8;
}else{echo "não identificado";}