<?php
header("Content-type:text/html;charset=utf8");
     $ano = $_POST["ano"];
     $idade = 2018 - $ano;
if($idade <= 16){
	echo "não pode";
}else{
	echo " pode ";
}
