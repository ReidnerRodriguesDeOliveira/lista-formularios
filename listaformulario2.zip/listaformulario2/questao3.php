<?php
header("Content-type:text/html;charset=utf8");
     $lados = $_POST["lados"];
     $tamanho = $_POST["tamanho"];
     $altura = $_POST["altura"]; 
     $base = $_POST["base"];              
if($lados == 3 && $altura != 0 && $base != 0 ){echo "triangulo AREA:".($base*$altura)/2  ;
}elseif($lados == 4){echo "quadrado AREA:".$tamanho*$tamanho;
}elseif($lados == 5){echo "pentagono";
}elseif($lados < 3){echo "não é um poligono";
}else{echo "não identificado";}