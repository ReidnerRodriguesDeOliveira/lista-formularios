<?php
header("Content-type:text/html;charset=utf8");
     $macas = $_POST["macas"];
if($macas <= 12){echo "R$". $macas*0.3;
}else{echo "R$". $macas*0.25;}