<?php
header("Content-type:text/html;charset=utf8");
     $altura = $_POST["altura"];
     $sexo = $_POST["sexo"];
$pesoF = 62.1 * $altura - 44.7;
$pesoM = 72.7 * $altura - 58;
if($sexo == "F"){
	echo "peso ideal feminino é: ".$pesoF ;
}else{
	echo "peso ideal masculino é: ".$pesoM;
}
