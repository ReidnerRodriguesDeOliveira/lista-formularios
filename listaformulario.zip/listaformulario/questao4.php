<?php
header("Content-type:text/html;charset=utf8");
//duas formas de receber valor no php
// GET -> envia o valor pelo url, não seguro
// POST -> envia pelo formulario html, seguro

//variaveis
$nome = "";
$nota1 = 0;
$nota2 = 0;
$nota3 = 0;
$maior1 = 0; 
$maior2 = 0;
$maiortotal = 0;
//calculo
// get- $_GET["nomeinput"]
// post- $_POST["nomeinput"]
if(isset($_POST["nome"])&& isset($_POST["nota"])){

$nome = $_POST["nome"];
$nota1 = $_POST["nota1"];
$nota2 = $_POST["nota2"];
$nota3 = $_POST["nota3"];
}

if($nota1 > $nota2){
	$maior1 = $nota1;
}else{
	$maior1 = $nota2;
}

if($nota2 > $nota3){
	$maior2 = $nota2;
}else{
	$maior2 = $nota2;
}

if($maior1 > $maior2){
	$maiortotal = $maior1;
}else{
	$maiortotal = $maior2;
}


//resultado
//<hr> serve para colocar uma linha estilosa no titulo
echo "o maior é: ".$maiortotal;

?>