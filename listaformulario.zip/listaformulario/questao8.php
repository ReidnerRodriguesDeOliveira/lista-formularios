<?php
header("Content-type:text/html;charset=utf8");
     $valor = $_POST["valor"];
     
if($valor>100&&$valor<200){
	echo "você digitou um numero entre 100 e 200";
}else{
	echo "você digitou um numero fora da faixa";
}
