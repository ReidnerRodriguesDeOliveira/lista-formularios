<?php
header("Content-type:text/html;charset=utf8");
//duas formas de receber valor no php
// GET -> envia o valor pelo url, não seguro
// POST -> envia pelo formulario html, seguro

//variaveis
$nome = "";
$nota1 = 0;
$nota2 = 0;
$nota3 = 0;
$nota4 = 0;
$media = 0; 

//calculo
// get- $_GET["nomeinput"]
// post- $_POST["nomeinput"]
if(isset($_POST["nome"])&& isset($_POST["nota"])){

$fnome = $_POST["nome"];
$fnota1 = $_POST["nota1"];
$fnota2 = $_POST["nota2"];
$fnota3 = $_POST["nota3"];
$fnota4 = $_POST["nota4"];

}



//resultado
//<hr> serve para colocar uma linha estilosa no titulo
if($nota1 <= 10 & $nota2 <= 10 & $nota3 <= 10 & $nota4 <= 10){
	$media = ($nota1+$nota2+$nota3+$nota4)/3;

}else{
	echo "nota ou nome não digitados";
}
if($media >=7 ){
	echo "aprovado";
}elseif($media >=5){
	echo "exame final";
}else{
	echo"reprovado";
}



?>