<?php
header("Content-type:text/html;charset=utf8");
//duas formas de receber valor no php
// GET -> envia o valor pelo url, não seguro
// POST -> envia pelo formulario html, seguro

//variavei

//calculo
// get- $_GET["nomeinput"]
// post- $_POST["nomeinput"]
$int = $_POST["int"];

//resultado
//<hr> serve para colocar uma linha estilosa no titulo
if($int % 2==1  ){
	echo " impar ";

}else{
echo "par";
} 


?>