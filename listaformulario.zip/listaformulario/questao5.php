<?php
header("Content-type:text/html;charset=utf8");
//duas formas de receber valor no php
// GET -> envia o valor pelo url, não seguro
// POST -> envia pelo formulario html, seguro

//variaveis
$idade = 0;

//calculo
// get- $_GET["nomeinput"]
// post- $_POST["nomeinput"]
if(isset($_POST["nome"])&& isset($_POST["nota"])){

$idade = $_POST["idade"];

}



//resultado
//<hr> serve para colocar uma linha estilosa no titulo
if($idade >= 18 ){
	echo "adulto";

}elseif($idade >= 14) {
    echo "juvenil";
}elseif($idade >= 9){
	echo "infantil";

}else{
	echo "mirin";


}



?>