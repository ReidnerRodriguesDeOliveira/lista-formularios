<?php
header("Content-type:text/html;charset=utf8");
//duas formas de receber valor no php
// GET -> envia o valor pelo url, não seguro
// POST -> envia pelo formulario html, seguro

//variaveis
$int = 0;

//calculo
// get- $_GET["nomeinput"]
// post- $_POST["nomeinput"]
if(isset($_POST["int"])){

$fnota1 = $_POST["int"];

}



//resultado
//<hr> serve para colocar uma linha estilosa no titulo
if($int < 3 ){
	echo" numero menor que 3";

}else if($int >25)
{
	echo "numero maior que 25";
}else{
	echo "numero entre 3 e 25";
}

?>