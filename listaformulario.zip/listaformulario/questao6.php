<?php
header("Content-type:text/html;charset=utf8");
     $salario = $_POST["salario"];
     $emprestimo = $_POST["emprestimo"];
     $prestacoes = $_POST["prestacoes"];
     $concedido = $salario * 0.3;
if($salario > $concedido){
	echo"negado";
}else{
	echo"concedido";
}