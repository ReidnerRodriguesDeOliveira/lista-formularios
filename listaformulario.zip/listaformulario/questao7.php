<?php
header("Content-type:text/html;charset=utf8");
     $valor = $_POST["valor"];
     $desconto = 0;
     
if($valor<20){
	$desconto = 1.45;
}else{
	$desconto = 1.30;
}
     $venda = $valor*$desconto;
echo"".$venda;